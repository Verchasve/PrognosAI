
import fetch from 'node-fetch';

export async function runOllama(prompt, model="llama3") {
  const res = await fetch("http://localhost:11434/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, prompt })
  });

  const data = await res.json();
  return data.response || JSON.stringify(data);
}
