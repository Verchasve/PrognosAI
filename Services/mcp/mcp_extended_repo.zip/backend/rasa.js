
import fetch from 'node-fetch';

export async function runRasa(text) {
  const res = await fetch("http://localhost:5005/model/parse", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });

  return await res.json();
}
