
import { runCustomModel } from './model.js';
import { runOllama } from './ollama.js';
import { runRasa } from './rasa.js';

// Simple heuristic router
export async function routeModel(text, ollamaModel="llama3") {
  const lower = text.toLowerCase();

  if (lower.includes("ticket") || lower.includes("issue") || lower.includes("servicenow") || lower.includes("jira"))
    return await runCustomModel(text);

  if (lower.startsWith("classify") || lower.includes("intent"))
    return await runRasa(text);

  return await runOllama(text, ollamaModel);
}
