
import { Server } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import { runCustomModel } from './model.js';
import { runOllama } from './ollama.js';
import { routeModel } from './router.js';
import { logRequest } from './logger.js';
import { runRasa } from './rasa.js';

const server = new Server({
  name: 'custom-mcp-server',
  version: '2.0.0',
});

// Middleware-style logging wrapper
async function wrap(handler) {
  return async (input) => {
    logRequest(input);
    return handler(input);
  };
}

server.tool(
  "predictWithCustomModel",
  {
    description: "Run inference using local custom model",
    inputSchema: z.object({ text: z.string() }),
  },
  wrap(async ({ text }) => ({ output: await runCustomModel(text) }))
);

server.tool(
  "predictWithOllama",
  {
    description: "Run inference using Ollama",
    inputSchema: z.object({ text: z.string(), model: z.string() })
  },
  wrap(async ({ text, model }) => ({ output: await runOllama(text, model) }))
);

server.tool(
  "predictWithRasa",
  {
    description: "Route text into Rasa NLU HTTP endpoint",
    inputSchema: z.object({ text: z.string() })
  },
  wrap(async ({ text }) => ({ output: await runRasa(text) }))
);

server.tool(
  "modelRouter",
  {
    description: "Automatically choose best model (custom, Rasa, Ollama)",
    inputSchema: z.object({
      text: z.string(),
      ollamaModel: z.string().optional()
    })
  },
  wrap(async ({ text, ollamaModel }) => ({ output: await routeModel(text, ollamaModel) }))
);

server.start();
