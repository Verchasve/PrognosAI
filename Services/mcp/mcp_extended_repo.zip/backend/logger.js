
import fs from 'fs';

export function logRequest(data) {
  const line = `[${new Date().toISOString()}] ${JSON.stringify(data)}\n`;
  fs.appendFileSync("mcp.log", line);
}
