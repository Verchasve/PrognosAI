
export async function runCustomModel(text) {
  return `Custom model received: ${text}`;
}
