# MCP Demo Full Repo

This repository contains a runnable demo:
- `server/` — Node.js MCP-like server exposing simple tools (queryCustomModel, predictRasa, createTicket)
- `python_model/` — Minimal Flask-based "custom model" service (keyword based)
- `frontend/` — React UI (development server) to interact with the MCP server
- `docker-compose.yml` — Bring everything up locally (python model, server, frontend)

## Quick start (Docker - recommended)
1. Install Docker & Docker Compose.
2. From repo root run:
   ```
   docker compose up --build
   ```
3. Open http://localhost:3000 to access the UI. The server is on port 3001 and the model on 5000.

## Quick start (local, no Docker)
### Python model
```
cd python_model
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

### Server
```
cd server
npm install
export CUSTOM_MODEL_URL=http://localhost:5000/predict
export JWT_SECRET=devsecret
node index.js
```

### Frontend
```
cd frontend
npm install
npm start
```

## Rasa integration
This demo expects a Rasa HTTP server if you want to use the `predictRasa` tool.
Run rasa as usual (not included in compose). Point `RASA_URL` to your Rasa endpoint (e.g. http://localhost:5005/model/parse).

## Security & production notes
- This demo uses a simple JWT dev token endpoint (`/auth/token`). Replace with OAuth2/OIDC in production.
- Add proper input validation, rate limits, service accounts, scopes & permissions for tool actions.
- Persist tickets to a database (Mongo/Postgres) if needed.

