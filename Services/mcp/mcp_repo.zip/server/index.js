import express from "express";
import cors from "cors";
import fetch from "node-fetch";
import jwt from "jsonwebtoken";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import { spawn } from "child_process";
dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || "change_this_secret";
const CUSTOM_MODEL_URL = process.env.CUSTOM_MODEL_URL || "http://python_model:5000/predict"; // when using docker-compose
const RASA_URL = process.env.RASA_URL || process.env.RASA_URL || "http://localhost:5005/model/parse";

// Simple auth middleware: expects Authorization: Bearer <token>
function authMiddleware(req,res,next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({error:"missing auth"});
  const [,token] = h.split(" ");
  try{
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  }catch(e){
    return res.status(401).json({error:"invalid token"});
  }
}

// Simple token generation (for dev). In production use proper OAuth flow.
app.post("/auth/token", (req,res)=>{
  const {user} = req.body;
  if(!user) return res.status(400).json({error:"provide user"});
  const token = jwt.sign({sub:user}, JWT_SECRET, {expiresIn:"12h"});
  res.json({token});
});

// MCP-like discovery endpoint
app.get("/.well-known/mcp", (req,res)=>{
  res.json({
    name:"custom-mcp-server",
    version:"1.0.0",
    tools:[
      {name:"queryCustomModel", description:"Query the hosted custom model", input:{text:"string"}},
      {name:"predictRasa", description:"Run Rasa NLU parse", input:{text:"string"}},
      {name:"createTicket", description:"Create a dummy ticket (example action)", input:{title:"string", body:"string"}}
    ]
  });
});

// Tool: queryCustomModel
app.post("/tool/queryCustomModel", authMiddleware, async (req,res)=>{
  const {text} = req.body;
  if(!text) return res.status(400).json({error:"text required"});
  try{
    // call external model service
    const r = await fetch(CUSTOM_MODEL_URL, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({text})});
    const j = await r.json();
    return res.json({result:j});
  }catch(e){
    console.error("model call failed",e);
    return res.status(500).json({error:"model_call_failed", detail:String(e)});
  }
});

// Tool: predictRasa
app.post("/tool/predictRasa", authMiddleware, async (req,res)=>{
  const {text} = req.body;
  if(!text) return res.status(400).json({error:"text required"});
  try{
    const r = await fetch(RASA_URL, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({text})});
    const j = await r.json();
    return res.json({result:j});
  }catch(e){
    console.error("rasa call failed",e);
    return res.status(500).json({error:"rasa_call_failed", detail:String(e)});
  }
});

// Tool: createTicket (example action)
let ticketCounter = 1000;
app.post("/tool/createTicket", authMiddleware, (req,res)=>{
  const {title, body} = req.body;
  const id = "TCK-"+(ticketCounter++);
  // In a real app you'd persist to DB / call ServiceNow or Jira
  res.json({ticket:{id, title, body, createdBy:req.user?.sub || "unknown"}});
});

// Simple endpoint for frontend dev to call a "mcp-like" single entry (optional)
app.post("/mcp", authMiddleware, async (req,res)=>{
  // expect {tool, input}
  const {tool, input} = req.body;
  if(!tool) return res.status(400).json({error:"tool name required"});
  if(tool==="queryCustomModel") return app._router.handle({...req, url:"/tool/queryCustomModel", method:"POST"}, res);
  if(tool==="predictRasa") return app._router.handle({...req, url:"/tool/predictRasa", method:"POST"}, res);
  if(tool==="createTicket") return app._router.handle({...req, url:"/tool/createTicket", method:"POST"}, res);
  return res.status(404).json({error:"unknown tool"});
});

app.listen(PORT, ()=>console.log("MCP-like server running on",PORT));
