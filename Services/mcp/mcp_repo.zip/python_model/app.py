from flask import Flask, request, jsonify
app = Flask(__name__)

# Very small toy "custom model" - keyword-based predictions for demo
mapping = {
    "password": {"intent":"password_reset","confidence":0.95, "answer":"Please follow the internal password reset flow."},
    "vpn": {"intent":"vpn_issue","confidence":0.9, "answer":"Check VPN server status and user's access group."},
    "billing": {"intent":"billing","confidence":0.88, "answer":"Forwarding to billing team."}
}

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    text = (data.get("text") or "").lower()
    for k,v in mapping.items():
        if k in text:
            return jsonify({"prediction":v,"source":"keyword_model"})
    # fallback
    return jsonify({"prediction":{"intent":"unknown","confidence":0.4,"answer":"I couldn't classify confidently."},"source":"keyword_model"})

if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000)
