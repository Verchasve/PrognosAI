import React, {useState} from 'react';
export default function App(){
  const [text,setText]=useState("");
  const [out,setOut]=useState(null);
  const [token,setToken]=useState("");
  async function getToken(){
    const r = await fetch("http://localhost:3001/auth/token",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({user:"dev-user"})});
    const j = await r.json();
    setToken(j.token);
    return j.token;
  }
  async function callTool(tool){
    const t = token || await getToken();
    const r = await fetch("http://localhost:3001/mcp", {method:"POST", headers:{"Content-Type":"application/json","Authorization":"Bearer "+t}, body:JSON.stringify({tool, input:{text}})});
    const j = await r.json();
    setOut(j);
  }
  return (<div style={{fontFamily:"Arial",padding:24}}>
    <h2>MCP UI — Demo</h2>
    <textarea rows={4} style={{width:"100%"}} value={text} onChange={e=>setText(e.target.value)} placeholder="Type a user prompt..."/>
    <div style={{marginTop:12}}>
      <button onClick={()=>callTool("queryCustomModel")} style={{marginRight:8}}>Call Custom Model</button>
      <button onClick={()=>callTool("predictRasa")} style={{marginRight:8}}>Call Rasa NLU</button>
      <button onClick={async ()=>{
        const tkn = token || await getToken();
        const r = await fetch("http://localhost:3001/tool/createTicket",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+tkn},body:JSON.stringify({title:"Demo",body:text})});
        setOut(await r.json());
      }}>Create Ticket</button>
    </div>
    <pre style={{background:"#f6f6f6",padding:12,marginTop:16}}>{JSON.stringify(out,null,2)}</pre>
  </div>);
}
